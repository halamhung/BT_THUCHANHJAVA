package halamhung_Buoi3.Bt3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bt3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bt3Application.class, args);
	}

}
