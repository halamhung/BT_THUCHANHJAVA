package doantrungkien.com.BaiTap3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiTap3Application {

	public static void main(String[] args) {
		SpringApplication.run(BaiTap3Application.class, args);
	}

}
